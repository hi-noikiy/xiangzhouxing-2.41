// pages/car-code/bus-code/passenger/detail/index.js
const passengerService = require('../.././../../../services/car-code/passenger.js');
const { config } = getApp();
const { Poster }= require('../../../../../miniprogram_dist/poster/poster');
const colLeft = 80;
const col2Left = 657;
const posterConfig = {
    width: 737,
    height: 1123,
    backgroundColor: '#fff',
    debug: false,
    pixelRatio: 1,
    blocks: [
        {
            width: 634,
            height: 74,
            x: 59,
            y: 770,
            backgroundColor: '#fff',
            opacity: 0.5,
            zIndex: 100,
        },
    ],
    texts: [
        {
            x: colLeft,
            y: 690,
            fontSize: 48,
            baseLine: 'middle',
            text: '交通卡口登记信息',
            width: 420,
            lineNum: 1,
            color: '#000',
            zIndex: 200,
        },
        {
            x: colLeft,
            y: 810,
            fontSize: 44,
            baseLine: 'middle',
            text: '',
            width: 420,
            lineNum: 1,
            color: '#000',
            zIndex: 200,
        },
        {
            x: col2Left,
            y: 810,
            textAlign: 'right',
            fontSize: 32,
            baseLine: 'middle',
            text: '广东揭阳-广东广州',
            width: 420,
            lineNum: 1,
            color: '#666',
            zIndex: 200,
        },
        {
            x: colLeft,
            y: 880,
            fontSize: 32,
            baseLine: 'middle',
            text: '班次号',
            width: 420,
            lineNum: 1,
            color: '#666',
            zIndex: 200,
        },
        {
            x: col2Left,
            textAlign: 'right',
            y: 880,
            fontSize: 32,
            textAlign: 'right',
            baseLine: 'middle',
            text: '2341231',
            width: 420,
            lineNum: 1,
            color: '#666',
            zIndex: 200,
        },
        {
            x: colLeft,
            y: 940,
            fontSize: 32,
            baseLine: 'middle',
            text: '乘车人',
            width: 420,
            lineNum: 1,
            color: '#666',
            zIndex: 200,
        },
        {
            x: col2Left,
            textAlign: 'right',
            y: 940,
            fontSize: 32,
            baseLine: 'middle',
            textAlign: 'right',
            text: '3人',
            width: 420,
            lineNum: 1,
            color: '#666',
            zIndex: 200,
        }
    ],
    images: [
        {
            width: 528,
            height: 528,
            x: 114.5,
            y: 55,
            borderRadius: 0,
            url: '',
        }
    ]
};

Page({
  /**
   * 页面的初始数据
   */
  data: {
    //行程id
    checkPointRegisterId:"",
    url: "https://suikang-prod-1251947680.cos.ap-guangzhou.myqcloud.com/car-code/wechat.png",
    formData: {
        id: '',
        carNum: "",
        routerNo: ""
      },
      posterConfig,
      passengerList:[],
      //当前用户身份证号
      identityNo:""
  },
   // 长按图片
   saveImg(e) {
    let _this = this;
    let url = e.currentTarget.dataset.url;
    wx.getSetting({
        success: (res) => {
            if (!res.authSetting['scope.writePhotosAlbum']) {
                wx.authorize({
                    scope: 'scope.writePhotosAlbum',
                    success: () => {
                        // 同意授权
                        _this.saveImgInner(url);
                    },
                    fail: (res) => {
                        console.log(res);
                        wx.showModal({
                            title: '保存失败',
                            content: '请开启访问手机相册权限',
                            success(res) {
                                wx.openSetting()
                            }
                        })
                    }
                })
            } else {
                // 已经授权了
                _this.saveImgInner(url);
            }
        },
        fail: (res) => {
            console.log(res);
        }
    })
},
// 长按保存功能--保存部分
saveImgInner(url) {
    wx.getImageInfo({
        src: url,
        success: (res) => {
            let path = res.path;
            wx.saveImageToPhotosAlbum({
                filePath: path,
                success: (res) => {
                    console.log(res);
                    wx.showToast({
                        title: '已保存到相册',
                    })
                },
                fail: (res) => {
                    console.log(res);
                }
            })
        },
        fail: (res) => {
            console.log(res);
        }
    })
},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let id=options.id?options.id:'677643519996723200';
    let identityNo=options.identityNo?options.identityNo:'10022551214';
    console.info(id)
    this.setData({checkPointRegisterId:id});
    this.setData({identityNo:identityNo});
    let string = config[config.env].cardCodePath + "/busDriver/v1/getCheckPointRegister?key="
        this.setData({
            url: string + options.id
        })
        this.getTravelInfo();
        this.getPointPassengerList();
        console.log("二维码获取地址", this.data.url)
  },

  /**
   * 跳转会卡口编辑页面
   */
  toEditPage(){
    wx.navigateTo({ url: '/pages/car-code/bus-code/passenger/edit/index?id='+this.data.checkPointRegisterId });
  },
  //获取行程信息
  getTravelInfo(){
 //根据id获取行程信息
 passengerService.getTravelInfoById({ checkPointId: this.data.checkPointRegisterId }).then((res) => {
    // console.info("行程信息=====================================")
    // console.info(res)
    let str=res.leaveProvinceName+res.leaveCityName+"-"+res.arriveProvinceName+res.arriveCityName
    var data = {
      id: res.id,
      carNum: res.carNumber,
      routerNo: res.carBatchNo,
      address:str
    }
    console.info(data)
    this.setData({
      formData: data
    })
  })
  },
  //根据行程id获取同乘人
  getPointPassengerList() {
    //根据行程id获取同行人信息
    passengerService.getPointPassengerList({ checkPointRegisterId: this.data.checkPointRegisterId, roleState: "2",createUserId:this.data.identityNo }).then((res) => {
      console.info("同行人信息=====================================")
      console.info(res)
      if (res && res.length > 0) {
        let userAllInfo=[];
        let personList = res.filter(item => {
          let isMe = item.identityNo == this.data.createUserId;
          item.phone = item.phone || '';
          item.mark = isMe ? "本人" : "";
          if(isMe){
            userAllInfo.push(item);
          }
          return !isMe;
        })
        personList = userAllInfo.concat(personList);
        this.setData({
          passengerList: personList
        })
      }
    })
  },
   // 异步生成
   onCreatePoster() {
    const { posterConfig, url, formData, passengerList } = this.data;
    posterConfig.images[0].url = url;
    posterConfig.texts[1].text = formData.carNum;
    posterConfig.texts[2].text = formData.address;
    posterConfig.texts[4].text = formData.routerNo;
    posterConfig.texts[6].text = passengerList.length + '人';
    this.setData({ posterConfig }, () => {
      Poster.create(true);    // 入参：true为抹掉重新生成
  });
},
onPosterSuccess(e) {
  console.log(e)
  const { detail } = e;
  wx.previewImage({
      current: detail,
      urls: [detail]
  })
},

onPosterFail(err) {
  console.error(err);
},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})